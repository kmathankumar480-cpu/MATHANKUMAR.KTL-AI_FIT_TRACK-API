const express = require('express');
const { getWorkoutRecommendation } = require('../controllers/aiController');

const router = express.Router();

router.post('/workout-recommendation', getWorkoutRecommendation);

module.exports = router;
