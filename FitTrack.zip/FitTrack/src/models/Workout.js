const mongoose = require('mongoose');

const workoutSchema = new mongoose.Schema(
  {
    workoutName: {
      type: String,
      required: [true, 'Workout name is required'],
      trim: true
    },
    category: {
      type: String,
      required: [true, 'Category is required'],
      trim: true
    },
    duration: {
      type: Number,
      required: [true, 'Duration (minutes) is required'],
      min: 0
    },
    caloriesBurned: {
      type: Number,
      required: [true, 'Calories burned is required'],
      min: 0
    },
    workoutDate: {
      type: Date,
      required: [true, 'Workout date is required']
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Workout', workoutSchema);
