const { generateContent } = require('../services/geminiService');

// @desc    Get an AI-generated workout recommendation
// @route   POST /api/ai/workout-recommendation
// @access  Public (add `protect` middleware in routes to make it Private)
const getWorkoutRecommendation = async (req, res, next) => {
  try {
    const { age, fitnessGoal, experience } = req.body;

    if (!age || !fitnessGoal || !experience) {
      return res.status(400).json({
        success: false,
        message: 'Please provide age, fitnessGoal and experience'
      });
    }

    const prompt = `You are a certified fitness coach. Create a concise, actionable weekly workout
recommendation for a person with the following profile:
- Age: ${age}
- Fitness goal: ${fitnessGoal}
- Experience level: ${experience}

Include: overall focus, weekly frequency, a sample routine with sets/reps or duration,
and one safety tip. Keep it practical and to the point.`;

    const recommendation = await generateContent(prompt);

    return res.status(200).json({ recommendation });
  } catch (error) {
    next(error);
  }
};

module.exports = { getWorkoutRecommendation };
