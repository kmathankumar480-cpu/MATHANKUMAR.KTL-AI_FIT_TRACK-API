const Workout = require('../models/Workout');

// @desc    Create a new workout
// @route   POST /api/workouts/
// @access  Private
const createWorkout = async (req, res, next) => {
  try {
    const { workoutName, category, duration, caloriesBurned, workoutDate } = req.body;

    if (!workoutName || !category || !duration || !caloriesBurned || !workoutDate) {
      return res.status(400).json({ success: false, message: 'Please provide all required workout fields' });
    }

    const workout = await Workout.create({
      workoutName,
      category,
      duration,
      caloriesBurned,
      workoutDate,
      user: req.user._id
    });

    return res.status(201).json({ success: true, data: workout });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all workouts for the logged-in user
// @route   GET /api/workouts/
// @access  Private
const getWorkouts = async (req, res, next) => {
  try {
    const workouts = await Workout.find({ user: req.user._id }).sort({ workoutDate: -1 });

    return res.status(200).json({
      success: true,
      count: workouts.length,
      data: workouts
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get a single workout by ID
// @route   GET /api/workouts/:id
// @access  Private
const getWorkoutById = async (req, res, next) => {
  try {
    const workout = await Workout.findById(req.params.id);

    if (!workout) {
      return res.status(404).json({ success: false, message: 'Workout not found' });
    }

    if (workout.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized to access this workout' });
    }

    return res.status(200).json({ success: true, data: workout });
  } catch (error) {
    next(error);
  }
};

// @desc    Update a workout
// @route   PUT /api/workouts/:id
// @access  Private
const updateWorkout = async (req, res, next) => {
  try {
    let workout = await Workout.findById(req.params.id);

    if (!workout) {
      return res.status(404).json({ success: false, message: 'Workout not found' });
    }

    if (workout.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized to update this workout' });
    }

    const { workoutName, category, duration, caloriesBurned, workoutDate } = req.body;

    workout.workoutName = workoutName ?? workout.workoutName;
    workout.category = category ?? workout.category;
    workout.duration = duration ?? workout.duration;
    workout.caloriesBurned = caloriesBurned ?? workout.caloriesBurned;
    workout.workoutDate = workoutDate ?? workout.workoutDate;

    workout = await workout.save();

    return res.status(200).json({ success: true, data: workout });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a workout
// @route   DELETE /api/workouts/:id
// @access  Private
const deleteWorkout = async (req, res, next) => {
  try {
    const workout = await Workout.findById(req.params.id);

    if (!workout) {
      return res.status(404).json({ success: false, message: 'Workout not found' });
    }

    if (workout.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized to delete this workout' });
    }

    await workout.deleteOne();

    return res.status(200).json({ success: true, message: 'Workout removed successfully' });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createWorkout,
  getWorkouts,
  getWorkoutById,
  updateWorkout,
  deleteWorkout
};
