# FitTrack API

Node.js + Express + MongoDB backend matching the endpoints tested in Thunder Client:
JWT auth, workout CRUD, and an AI workout recommendation endpoint (Google Gemini).

## Setup

```bash
npm install
cp .env.example .env   # fill in MONGO_URI, JWT_SECRET, GEMINI_API_KEY
npm run dev             # or: npm start
```

## Endpoints

### Auth
| Method | Route | Auth | Body |
|---|---|---|---|
| POST | /api/auth/register | Public | `{ name, email, password }` |
| POST | /api/auth/login | Public | `{ email, password }` |
| GET | /api/auth/profile | Bearer token | – |

### Workouts (all require `Authorization: Bearer <token>`)
| Method | Route | Body |
|---|---|---|
| POST | /api/workouts/ | `{ workoutName, category, duration, caloriesBurned, workoutDate }` |
| GET | /api/workouts/ | – |
| GET | /api/workouts/:id | – |
| PUT | /api/workouts/:id | any subset of workout fields |
| DELETE | /api/workouts/:id | – |

### AI
| Method | Route | Body |
|---|---|---|
| POST | /api/ai/workout-recommendation | `{ age, fitnessGoal, experience }` |

## Notes
- Passwords are hashed with bcrypt; JWTs are signed with `JWT_SECRET` and expire per `JWT_EXPIRES_IN`.
- Workouts are scoped to the logged-in user — one user cannot read/update/delete another's workout.
- The AI route calls Gemini's `generateContent` endpoint; set `GEMINI_API_KEY` and optionally `GEMINI_MODEL` in `.env`.
